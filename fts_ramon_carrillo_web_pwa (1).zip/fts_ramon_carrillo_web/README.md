# FTS Ramón Carrillo — Web/App

Versión PWA de la app estudiantil. El archivo principal es `index.html`.

## Publicar con GitHub Pages
1. Crear un repositorio público en GitHub.
2. Subir todos estos archivos manteniendo la misma estructura.
3. Ir a Settings → Pages.
4. En Build and deployment elegir `Deploy from a branch`.
5. Seleccionar `main` y `/ (root)` y guardar.
6. GitHub entregará una dirección `https://...github.io/.../`.

## Instalar como app
Desde Chrome/Edge en celular o PC, abrir la web publicada y usar “Instalar app” / “Agregar a pantalla de inicio” cuando el navegador lo ofrezca.

## Importante
La versión actual conserva datos de demandas, calendario y biblioteca en `localStorage`, por lo que todavía no son compartidos entre usuarios. Para convertirla en una app realmente colectiva habrá que conectar una base de datos y almacenamiento de archivos (por ejemplo Supabase) y agregar usuarios/permisos.
